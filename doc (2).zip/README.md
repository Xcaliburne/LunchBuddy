LunchBuddy
==========
Installation :
 - Installer EasyPhp 14.1VC11
 - démarrer EasyPhp
 - exécuter le script LunchBuddy.sql dans PHPMyAdmin
 - créer un Alias pointant sur le repertoire LunchBuddy
 - connecter le serveur à internet pour l'accès à l'API de geolocalisation